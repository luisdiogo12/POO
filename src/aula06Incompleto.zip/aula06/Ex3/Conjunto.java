package aula06.Ex3;

public class Conjunto {
	static int[] arrayInt;
	int num;

	public Conjunto(int num) {
		if (validInt(num)){
			this.num = num;
			insertNum(num);
		}else{
			System.out.println("Numero repetido");
		}
	}
	
	//+:array de int dinamico
	private void insertNum(int num) {
		if (arrayInt == null){
			arrayInt = new int[1];
			arrayInt[0] = num;
		}else{
			int[] newArray = new int[arrayInt.length + 1];
			for (int i = 0; i < arrayInt.length; i++){
				newArray[i] = arrayInt[i];
			}
			newArray[arrayInt.length] = num;
			arrayInt = newArray;
		}
	}

	private Boolean validInt(int num){
		for (int i = 0; i < arrayInt.length; i++){
			if (arrayInt[i] == num){
				return false;
			}
		}
		return true;
	}

	public void insert(int num) {
		if (validInt(num)){
			insertNum(num);
		}else{
			System.out.println("Numero repetido");
		}
	}

}
