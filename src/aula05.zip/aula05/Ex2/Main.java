package aula05.Ex2;

public class Main {

	public static void main(String[] args){

		
	}

	public static void showMenu(){
		System.out.println("Calendar operations:");
		System.out.printf("1 - create new date\n2 - print calendar month\n3 - print calendar\n0 - exit");
	}
	
}
