package aula05.Ex2;

import aula05.Ex1.DateYMD;

public class Calendar {
	private int[][] events;
	private int year;
	private int weekDay;
	 String[] months = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};

	public Calendar(int year, int weekDay){
		this.year = year;
		this.weekDay = weekDay;
	}

	public void printMonth(int month){

		
	}
	

}
